-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 25 nov 2019 om 23:45
-- Serverversie: 10.4.6-MariaDB
-- PHP-versie: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `php_crud`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `ageinyears` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT 0,
  `ageindays` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `members`
--

INSERT INTO `members` (`id`, `fname`, `lname`, `contact`, `ageinyears`, `active`, `ageindays`) VALUES
(13, 'Danique', 'Ursem', '', '2001-08-30', 1, ''),
(14, 'Natasja', 'Ursem', '', '1996-09-06', 1, ''),
(15, 'Jeffrey', 'Ursem', '', '1985-08-10', 1, ''),
(16, 'Ingrid', 'Ursem', '', '1962-10-19', 1, ''),
(17, 'Wesley', 'Ursem', '', '1982-08-29', 1, ''),
(18, 'Simone', 'Ursem', '', '1987-05-09', 1, ''),
(19, 'Simone', 'Ursem', '', '1987-05-09', 2, ''),
(20, 'Simone', 'Ursem', '', '1987-05-09', 2, ''),
(21, 'Rene', 'Ursem', '', '1962-10-27', 1, '');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
